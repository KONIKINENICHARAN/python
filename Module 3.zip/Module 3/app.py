from flask import Flask, render_template, jsonify, redirect, url_for, request, session
import json
import utils

app = Flask(__name__)
app.config['SECRET_KEY'] = 'the random string'

try:
    with open('details.json', 'r') as f:
        users = json.load(f)
except FileNotFoundError:
    users = {}

news_list = utils.get_news()["articles"][:6]

class Post:
    def __init__(self, title, image_url):
        self.title = title
        self.image_url = image_url

posts = [Post(news["title"], news["urlToImage"]) for news in news_list]

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        latitude = request.form['latitude']
        longitude = request.form['longitude']
        session['latitude'] = latitude
        session['longitude'] = longitude

        username = request.form['email']
        password = request.form['password']

        print(f'user {username} password {password} ')
        
        if username in users and users[username] == password:
            return redirect(url_for('weatherDetails'))
        
        error = 'Invalid username or password'
        return render_template('Login.html', error=error)
    
    return render_template('Login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        confirmPassword = request.form['confirm-password']

        print(f'user {email} password {password} confirm pass {confirmPassword}')

        if password == confirmPassword:
            users[email] = password  # Hash the password before storing
            with open('details.json', 'w') as jf:
                json.dump(users, jf)
            return redirect(url_for('login'))
        else:
            error = 'Passwords do not match'
            return render_template('Signup.html', error=error)
    
    return render_template('Signup.html')

@app.route('/weatherDetails', methods=['GET', 'POST'])
def weatherDetails():
    data = utils.get_current_weather_data()
    return render_template('Weather.html', data=data)

def get_map(zone):
    maps = {
        "flood Map": utils.get_flood_map(),
        "lake": utils.get_lake_zones(),
        "drainage": utils.get_drainage_lines(),
    }
    return maps.get(zone, "default_map_url_if_zone_not_found")

@app.route('/floodzone', methods=['POST', 'GET'])
def floodzone():
    if request.method == 'POST':
        selected_zone = request.form.get('zone')
        map_image_url = get_map(selected_zone)
        return render_template('FloodZone.html', map=map_image_url)
    else:
        return render_template('FloodZone.html', map=None)

@app.route('/alert', methods=['POST', 'GET'])
def alert():    
    return render_template('Alert.html', posts=posts)

@app.route('/shelter', methods=['POST', 'GET'])
def shelter():
    if request.method == 'POST':
        location_data = request.json
        session['location_data'] = location_data
        return redirect(url_for('shelter_map_page'))

    return render_template('Shelter.html')

@app.route('/shelter_map_page', methods=['GET'])
def shelter_map_page():
    location_data = session.get('location_data')
    if location_data:
        latitude, longitude = utils.get_lat_long_for_ip()
        map_html = utils.shelter_map(latitude, longitude)
        return render_template('map.html', map=map_html)
    return "No location data found", 404

@app.route('/sos', methods=['POST', 'GET'])
def sos():
    if request.method == 'POST':
        name = request.form['name']
        situation = request.form['situation']
        contact = request.form['contact']
        utils.send_email(name, situation, contact)

    return render_template('Sos.html')

if __name__ == '__main__':
    app.run(debug=True)
